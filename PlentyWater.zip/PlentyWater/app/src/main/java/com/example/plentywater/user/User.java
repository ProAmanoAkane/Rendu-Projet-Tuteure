package com.example.plentywater.user;

public class User {
    public String type,masse,age,recurence;

    public User(String type, String masse ,String age , String recu){
            this.type = type;
            this.masse = masse;
            this.age = age;
            this.recurence = recu;
    }

        public String getMasse() {
            return masse;
        }

        public String getType() {
            return type;
        }

        public String getAge() {
            return age;
        }

        public String getRecurence() {
            return recurence;
        }

        public void setMasse(String masse) {
            this.masse = masse;
        }

        public void setType(String type) {
            this.type = type;
        }

        public void setAge(String age) {
            this.age = age;
        }

        public void setRecurence(String recurence) {
            this.recurence = recurence;
        }

        @Override public String toString() {
            return "utilisateur{" +
                    "type='" + type + '\'' +
                    ", masse='" + masse + '\'' +
                    ", age='" + age + '\'' +
                    ", recurence='" + recurence + '\'' +
                    '}';
        }


}
