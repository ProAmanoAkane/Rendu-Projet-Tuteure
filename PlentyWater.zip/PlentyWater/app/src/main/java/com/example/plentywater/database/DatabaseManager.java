package com.example.plentywater.database;

import android.content.Context;

import com.example.plentywater.sharedpreferences.LanguageSharedPreferences;
import com.example.plentywater.sharedpreferences.MeasuresSharedPreferences;

public class DatabaseManager {
    public static DatabaseManager INSTANCE;
    private LanguageSharedPreferences languageSetting;
    private MeasuresSharedPreferences measuresSetting;

    private DatabaseManager(){}

    public static DatabaseManager getInstance(Context context) {
        if (INSTANCE == null) {
           INSTANCE = new DatabaseManager();
           INSTANCE.init(context);
        }
        return INSTANCE;
    }

    public void setLanguage(String settingStr) {
        languageSetting.saveSetting(settingStr);
    }

    public void setMeasures(String settingStr) {
        languageSetting.saveSetting(settingStr);
    }

    public String getLanguage() {
        return languageSetting.getSetting();
    }

    public String getMeasures() {
        return measuresSetting.getSetting();
    }

    public void removeLanguage() {
        languageSetting.removeSetting();
    }

    public void removeMeasures() {
        languageSetting.removeSetting();
    }

    public void clearLanguage() {
        languageSetting.clearAll();
    }

    public void clearMeasures(){
        measuresSetting.clearAll();
    }

    public void clearAll(){
        languageSetting.clearAll();
        measuresSetting.clearAll();
    }

    private void init(Context context){
        languageSetting = LanguageSharedPreferences.getInstance(context);
        measuresSetting = MeasuresSharedPreferences.getInstance(context);
    }
}
