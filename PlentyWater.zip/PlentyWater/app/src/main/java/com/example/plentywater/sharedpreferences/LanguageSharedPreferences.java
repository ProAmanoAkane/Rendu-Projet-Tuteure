package com.example.plentywater.sharedpreferences;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class LanguageSharedPreferences {
    private static LanguageSharedPreferences sharePref = new LanguageSharedPreferences();
    private static SharedPreferences sharedPreferences;
    private static SharedPreferences.Editor editor;

    private static final String LANGUAGE_SETTING = "language_settings";

    private LanguageSharedPreferences(){}

    public static LanguageSharedPreferences getInstance(Context context) {
        if (sharedPreferences == null) {
            sharedPreferences = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
            editor = sharedPreferences.edit();
        }
        return sharePref;
    }

    public void saveSetting(String settingStr) {
        editor.putString(LANGUAGE_SETTING, settingStr);
        editor.commit();
    }

    public String getSetting() {
        return sharedPreferences.getString(LANGUAGE_SETTING, "");
    }


    public void removeSetting() {
        editor.remove(LANGUAGE_SETTING);
        editor.commit();
    }

    public void clearAll() {
        editor.clear();
        editor.commit();
    }

}
