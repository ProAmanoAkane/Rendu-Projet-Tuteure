package com.example.plentywater.sharedpreferences;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class MeasuresSharedPreferences {
    private static MeasuresSharedPreferences sharePref = new MeasuresSharedPreferences();
    private static SharedPreferences sharedPreferences;
    private static SharedPreferences.Editor editor;

    private static final String MEASURES_SETTINGS = "measures_settings";

    private MeasuresSharedPreferences(){}

    public static MeasuresSharedPreferences getInstance(Context context) {
        if (sharedPreferences == null) {
            sharedPreferences = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
            editor = sharedPreferences.edit();
        }
        return sharePref;
    }

    public void saveSetting(String settingStr) {
        editor.putString(MEASURES_SETTINGS, settingStr);
        editor.commit();
    }

    public String getSetting() {
        return sharedPreferences.getString(MEASURES_SETTINGS, "");
    }


    public void removeSetting() {
        editor.remove(MEASURES_SETTINGS);
        editor.commit();
    }

    public void clearAll() {
        editor.clear();
        editor.commit();
    }

}
