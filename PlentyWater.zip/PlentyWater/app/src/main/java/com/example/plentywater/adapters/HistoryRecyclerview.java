package com.example.plentywater.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.plentywater.R;

public class HistoryRecyclerview extends RecyclerView.Adapter<HistoryRecyclerview.HistoryViewholder>{

    String data1[], data2[];
    int images[];
    Context context;

    public HistoryRecyclerview(Context ct, String s1[], String s2[], int img[]){
        context = ct;
        data1 = s1;
        data2 = s2;
        images = img;
    }


    @NonNull
    @Override
    public HistoryViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.viewholder_drink, parent, false);
        return new HistoryViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewholder holder, int position) {
        holder.txt1.setText(data1[position]);
        holder.txt2.setText(data2[position]);
        holder.myImage.setImageResource(images[position]);
    }

    @Override
    public int getItemCount() {
        return images.length;
    }

    public class HistoryViewholder extends RecyclerView.ViewHolder {

        TextView txt1, txt2;
        ImageView myImage;

        public HistoryViewholder(@NonNull View itemView) {
            super(itemView);
            txt1 = itemView.findViewById(R.id.contenants_txt);
            txt2 = itemView.findViewById(R.id.description_txt);
            myImage = itemView.findViewById(R.id.myImageView);
        }
    }
}
