package com.example.plentywater.parametersActivies;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.plentywater.R;
import com.example.plentywater.database.DatabaseManager;

public class LanguageActivity extends AppCompatActivity {
    private DatabaseManager db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        final Button francais = (Button) findViewById(R.id.bFr);
        final Button anglais = (Button) findViewById(R.id.bEng);
        final Button allemand = (Button) findViewById(R.id.bDeu);
        final Button espagnol = (Button) findViewById(R.id.bSpa);
        db = DatabaseManager.getInstance(getApplicationContext());

        francais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.setLanguage("français");
                afficheText();

            }
        });

        anglais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.setLanguage("anglais");
                afficheText();
            }
        });

        allemand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.setLanguage("allemand");
                afficheText();
            }
        });

        espagnol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.setLanguage("espagnol");
                afficheText();
            }
        });

    }

    private void afficheText() {
        Toast.makeText(LanguageActivity.this, db.getLanguage(), Toast.LENGTH_SHORT).show();
    }

}