package com.example.plentywater.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.util.JsonWriter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.plentywater.HomeActivity;
import com.example.plentywater.R;
import com.example.plentywater.RegistrationActivity;
import com.example.plentywater.sharedpreferences.RegistrationSharedPref;
import com.example.plentywater.user.User;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link InscriptionFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class InscriptionFragment extends Fragment {
    EditText _age, _weight;
    RadioGroup _radio;
    RadioButton _sexes;
    String age, weight, sex, recurrence;
    Button next;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public InscriptionFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment InscriptionFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static InscriptionFragment newInstance(String param1, String param2) {
        InscriptionFragment fragment = new InscriptionFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inscription, container, false);

        Spinner spinner = view.findViewById(R.id.spinActivity);
        _age = view.findViewById(R.id.etAge);
        _weight = view.findViewById(R.id.etWeight);
        _radio = view.findViewById(R.id.rgSexes);
        next = view.findViewById(R.id.btnNext);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weight = _weight.getText().toString();
                age = _age.getText().toString();
                int selectedId = _radio.getCheckedRadioButtonId();
                _sexes = view.findViewById(selectedId);
                sex = _sexes.getText().toString();
                if (spinner.getSelectedItem().toString().equals("Rare")) recurrence = "rare";
                if (spinner.getSelectedItem().toString().equals("Quelques fois")) recurrence = "QF";
                if (spinner.getSelectedItem().toString().equals("Souvent")) recurrence = "souvent";
                if (spinner.getSelectedItem().toString().equals("Très régulièrement")) recurrence = "TR";

                RegistrationSharedPref.write(RegistrationSharedPref.REGISTERED, true);

                User user = new User("null","null","null","null");
                user.setMasse(weight);
                user.setType(sex);
                user.setAge(age);
                user.setRecurence(recurrence);

                try {
                    StringWriter output = new StringWriter();
                    JsonWriter jsonWriter = new JsonWriter(output);
                    jsonWriter.beginObject();// begin root
                    jsonWriter.name("masse").value(user.getMasse());
                    jsonWriter.name("sexe").value(user.getType());
                    jsonWriter.name("age").value(user.getAge());
                    jsonWriter.name("recu").value(user.getRecurence());
                    jsonWriter.endObject();
                }
                catch (Exception e){
                    e.printStackTrace();
                }

                Intent intent = new Intent(getActivity(), HomeActivity.class);
                getActivity().finish();
                startActivity(intent);
            }
        });


        return view;

    }

    public static void writeJsonStream(Writer output, User u1 ) throws IOException {

        JsonWriter jsonWriter = new JsonWriter(output);
        jsonWriter.beginObject();// begin root
        jsonWriter.name("masse").value(u1.getMasse());
        jsonWriter.name("sexe").value(u1.getType());
        jsonWriter.name("age").value(u1.getAge());
        jsonWriter.name("recu").value(u1.getRecurence());
        jsonWriter.endObject();
    }

}