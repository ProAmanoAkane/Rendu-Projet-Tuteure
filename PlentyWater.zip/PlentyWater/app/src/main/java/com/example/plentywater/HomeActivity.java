package com.example.plentywater;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.example.plentywater.fragments.HistoryFragment;
import com.example.plentywater.fragments.HomeFragment;
import com.example.plentywater.fragments.InscriptionFragment;
import com.example.plentywater.fragments.SettingsFragment;
import com.example.plentywater.sharedpreferences.RegistrationSharedPref;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeActivity extends AppCompatActivity {
    private Fragment Settings = new SettingsFragment();
    private Fragment Home = new HomeFragment();
    private Fragment History = new HistoryFragment();

    private BottomNavigationView bottom_nav;
    FragmentManager fragmentManager = getSupportFragmentManager();
    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
    FrameLayout frame;
    private boolean registered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        RegistrationSharedPref.init(getApplicationContext());

        if(RegistrationSharedPref.exists()){
            registered = RegistrationSharedPref.read(RegistrationSharedPref.REGISTERED, false);
        }
        else registered = false;

        bottom_nav = findViewById(R.id.bottomNavigationView);
        frame = findViewById(R.id.flFragment);

        if(!registered){
            Intent intent = new Intent(HomeActivity.this, RegistrationActivity.class);
            finish();
            startActivity(intent);
        }

        fragmentTransaction.replace(frame.getId(), Home);
        fragmentTransaction.commit();


        bottom_nav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.miSetting:
                        FragmentTransaction support_managerr = getSupportFragmentManager().beginTransaction();
                        support_managerr.replace(frame.getId(), Settings);
                        support_managerr.addToBackStack(null);
                        support_managerr.commit();
                        return true;
                    case R.id.miHome:
                        FragmentTransaction support_manager = getSupportFragmentManager().beginTransaction();
                        support_manager.replace(frame.getId(), Home);
                        support_manager.addToBackStack(null);
                        support_manager.commit();
                        return true;
                    case R.id.miHistory:
                        FragmentTransaction _support_manager = getSupportFragmentManager().beginTransaction();
                        _support_manager.replace(frame.getId(), History);
                        _support_manager.addToBackStack(null);
                        _support_manager.commit();
                        return true;
                    default:
                        return true;
                }
            }
        });

    }
}