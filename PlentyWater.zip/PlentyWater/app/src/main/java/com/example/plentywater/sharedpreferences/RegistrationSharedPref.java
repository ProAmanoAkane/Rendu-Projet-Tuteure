package com.example.plentywater.sharedpreferences;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class RegistrationSharedPref {
    private static SharedPreferences mSharedPref;
    public static final String REGISTERED = "REGISTERED";

    private RegistrationSharedPref()
    {

    }

    public static void init(Context context)
    {
        if(mSharedPref == null)
            mSharedPref = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
    }

    public static Boolean read(String key, Boolean defValue) {
        return mSharedPref.getBoolean(key, defValue);
    }

    public static Boolean exists(){
        return mSharedPref.contains(REGISTERED);
    }

    public static void write(String key, Boolean value) {
        SharedPreferences.Editor prefsEditor = mSharedPref.edit();
        prefsEditor.putBoolean(key, value);
        prefsEditor.commit();
    }

}
