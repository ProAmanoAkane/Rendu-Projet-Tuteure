package com.example.plentywater.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.plentywater.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {
    Button b1,b2,b3,b4;
    TextView obj;

    int val = 0;
    ProgressBar p;
    TextView t;
    String rec;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_home, container, false);

        b1 = view.findViewById(R.id.button_decr);
        b2 = view.findViewById(R.id.button_incr);
        b3 = view.findViewById(R.id.button_decr2);
        b4 = view.findViewById(R.id.button_incr2);
        p = view.findViewById(R.id.progress_bar);
        t = view.findViewById(R.id.text_view_progress);
        obj = view.findViewById(R.id.textView);

        if(rec == "rare"){
            obj.setText("Obectif = 1 litre");
            p.setMax(100);
        }else if(rec == "QF"){
            obj.setText("Obectif = 1.25 litres");
            p.setMax(125);
        }else if(rec =="souvent"){
            obj.setText("Obectif = 1.5 litres");
            p.setMax(150);
        }else{
            obj.setText("Obectif = 2 litres");
            p.setMax(200);
        }

        updateProgressBar100ml();
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (val <= 300) {
                    val += 10;
                    updateProgressBar100ml();

                }
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (val >= 10) {
                    val -= 10;
                    updateProgressBar100ml();
                }
            }
        });
        updateProgressBar250ml();
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (val <= 300) {
                    val += 25;
                    updateProgressBar250ml();
                }
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (val >= 25) {
                    val -= 25;
                    updateProgressBar250ml();
                }
            }
        });

        return view;
    }

    void updateProgressBar100ml() {
        p.setProgress(val);
        int val2 = val * 10;
        t.setText(val2 + "ml");
    }
    void updateProgressBar250ml() {
        p.setProgress(val);
        int val2 = val*10;
        t.setText(val2+"ml");
    }
}