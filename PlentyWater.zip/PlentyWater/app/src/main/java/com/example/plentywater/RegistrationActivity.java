package com.example.plentywater;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.FrameLayout;

import com.example.plentywater.fragments.InscriptionFragment;

public class RegistrationActivity extends AppCompatActivity {

    private Fragment Registration = new InscriptionFragment();
    FragmentManager fragmentManager = getSupportFragmentManager();
    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
    FrameLayout frame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        frame = findViewById(R.id.flRegFragment);
        fragmentTransaction.replace(frame.getId(), Registration);
        fragmentTransaction.commit();

    }
}